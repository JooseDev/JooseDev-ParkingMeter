let slider = document.getElementById('slider');
let greenZone = document.getElementById('green-zone');
let direction = 1;
let speed = 3; // default, overridden by Lua
let running = false;
let animationFrame;

// default green zone size in pixels
let zoneSize = 100; 

window.addEventListener('message', function(event) {
    if (event.data.action === 'startGame') {
        // If difficulty data provided, set them
        if (event.data.speed) speed = event.data.speed * 3; // scaling for pixels/frame
        if (event.data.zoneSize) {
            zoneSize = event.data.zoneSize * 400; // scale to bar width
            greenZone.style.width = `${zoneSize}px`;
        }
        startGame();
    }
    if (event.data.action === 'closeGame') {
        stopGame();
    }
});

function startGame() {
    running = true;
    direction = 1;
    let position = 0;
    slider.style.left = position + 'px';
    document.getElementById('game').style.display = 'block';

    // Position green zone randomly each game
    let greenLeft = Math.floor(Math.random() * (400 - zoneSize));
    greenZone.style.left = `${greenLeft}px`;

    // Cancel any previous loop
    if (animationFrame) {
        cancelAnimationFrame(animationFrame);
    }

    function animate() {
        if (!running) return;
        position += direction * speed;
        if (position <= 0 || position >= 390) {
            direction *= -1;
        }
        slider.style.left = position + 'px';
        animationFrame = requestAnimationFrame(animate);
    }
    animate();
}

function stopGame() {
    running = false;
    if (animationFrame) {
        cancelAnimationFrame(animationFrame);
    }
    document.getElementById('game').style.display = 'none';
}

document.addEventListener('keydown', function(e) {
    if (e.code === 'Space' && running) {
        running = false;
        let sliderRect = slider.getBoundingClientRect();
        let greenRect = greenZone.getBoundingClientRect();
        if (sliderRect.left >= greenRect.left && sliderRect.right <= greenRect.right) {
            fetch(`https://${GetParentResourceName()}/success`, { method: 'POST' });
        } else {
            fetch(`https://${GetParentResourceName()}/fail`, { method: 'POST' });
        }
    }
});