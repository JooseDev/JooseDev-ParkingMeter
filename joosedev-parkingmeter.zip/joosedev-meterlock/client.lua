local callback = nil
local uiOpen = false

-- Difficulty table
local difficultyLevels = {
    [1] = { speed = 0.6, zoneSize = 0.35, label = "Easy" },
    [2] = { speed = 1.0, zoneSize = 0.25, label = "Medium" },
    [3] = { speed = 1.5, zoneSize = 0.15, label = "Hard" }
}

-- Ensure UI starts hidden
CreateThread(function()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'closeGame' })
end)

-- Event to start the game with difficulty
RegisterNetEvent('meterlock:start', function(difficulty, cb)
    callback = cb
    uiOpen = true

    -- Default to medium if invalid difficulty
    if not difficultyLevels[difficulty] then
        difficulty = 2
    end
    local settings = difficultyLevels[difficulty]

    -- Notify difficulty to player
    TriggerEvent('QBCore:Notify', "Difficulty: " .. settings.label, "primary", 2000)

    -- Open the NUI with difficulty settings
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'startGame',
        speed = settings.speed,
        zoneSize = settings.zoneSize
    })
end)

-- Success callback from NUI
RegisterNUICallback('success', function(_, cb)
    closeUI()
    if callback then callback(true) end
    callback = nil
    cb('ok')
end)

-- Fail callback from NUI
RegisterNUICallback('fail', function(_, cb)
    closeUI()
    if callback then callback(false) end
    callback = nil
    cb('ok')
end)

-- Debug command to close UI if stuck
RegisterCommand('closeminigame', function()
    closeUI()
end)

function closeUI()
    uiOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'closeGame' })
end