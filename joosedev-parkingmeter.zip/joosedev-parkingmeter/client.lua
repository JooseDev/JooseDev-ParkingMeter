local QBCore = exports['qb-core']:GetCoreObject()

local parkingMeters = {
    `prop_parknmeter_01`,
    `prop_parknmeter_02`
}

local exchangeProps = { `prop_vend_soda_02` } -- change to your machine prop
local exchangeLocations = {
    vector4(1143.7032, -990.9857, 45.7086, 277.6236), -- example location
    -- Add more coords if needed
}

CreateThread(function()
    for _, loc in ipairs(exchangeLocations) do
        local model = exchangeProps[1]
        RequestModel(model)
        while not HasModelLoaded(model) do Wait(10) end

        local obj = CreateObject(model, loc.x, loc.y, loc.z - 1.0, false, false, false)
        SetEntityHeading(obj, -260.5134)
        FreezeEntityPosition(obj, true)
        SetEntityInvincible(obj, true)

        exports['qb-target']:AddTargetEntity(obj, {
            options = {
                {
                    type = "client",
                    event = "qb-coinexchange:client:openMenu",
                    icon = "fas fa-coins",
                    label = "Exchange Quarters for Cash",
                }
            },
            distance = 2.0
        })
    end
end)

RegisterNetEvent('qb-coinexchange:client:openMenu', function()
    QBCore.Functions.TriggerCallback('qb-coinexchange:server:getCoinCount', function(count)
        if count > 0 then
            local worth = count * 0.25 -- Each quarter worth $0.25
            TriggerEvent("qb-menu:client:openMenu", {
                {
                    header = "Coin Exchange",
                    isMenuHeader = true
                },
                {
                    header = "Exchange "..count.." Quarters",
                    txt = "You will receive $"..worth.." cash.",
                    params = {
                        event = "qb-coinexchange:client:confirmExchange",
                        args = {
                            count = count,
                            worth = worth
                        }
                    }
                },
                {
                    header = "Cancel",
                    params = { event = "" }
                }
            })
        else
            QBCore.Functions.Notify("You have no quarters to exchange!", "error")
        end
    end)
end)

RegisterNetEvent('qb-coinexchange:client:confirmExchange', function(data)
    TriggerServerEvent('qb-coinexchange:server:exchangeCoins', data.count, data.worth)
end)

-- Add qb-target interaction
CreateThread(function()
    for _, model in ipairs(parkingMeters) do
        exports['qb-target']:AddTargetModel(model, {
            options = {
                {
                    type = "client",
                    event = "qb-parkingmeters:tryBreakIn",
                    icon = "fas fa-lock",
                    label = "Break into Parking Meter",
                    item = "lockpick",
                }
            },
            distance = 2.0
        })
    end
end)

-- Try to break into meter
RegisterNetEvent('qb-parkingmeters:tryBreakIn', function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local closestMeter = GetClosestObjectOfType(coords.x, coords.y, coords.z, 2.0, parkingMeters[1], false, false, false)
    if closestMeter == 0 then
        closestMeter = GetClosestObjectOfType(coords.x, coords.y, coords.z, 2.0, parkingMeters[2], false, false, false)
    end

    if closestMeter ~= 0 then
        local model = GetEntityModel(closestMeter)
        local meterCoords = GetEntityCoords(closestMeter)
        TriggerServerEvent('qb-parkingmeters:server:checkCooldown', model, meterCoords)
    end
end)

local function spawnCoinEffect(coords)
    local coinModel = `vw_prop_vw_coin_01a` -- You can swap this for another small object
    RequestModel(coinModel)
    while not HasModelLoaded(coinModel) do
        Wait(10)
    end

    for i = 1, 16 do -- spawn 8 coins
        local xOffset = math.random(-10, 10) / 100.0
        local yOffset = math.random(-10, 10) / 100.0
        local zOffset = 0.8

        local obj = CreateObject(coinModel, coords.x + xOffset, coords.y + yOffset, coords.z + zOffset, true, false, false)
        SetEntityVelocity(obj, math.random(-1, 1) + 0.0, math.random(-1, 1) + 0.0, math.random(2, 4) + 0.0)
        SetEntityAlpha(obj, 255, false)

        -- Auto delete after 5 seconds
        SetTimeout(5000, function()
            if DoesEntityExist(obj) then
                DeleteEntity(obj)
            end
        end)
    end
end

-- Start minigame after cooldown check
RegisterNetEvent('qb-parkingmeters:client:startMinigame', function(model, coords)
    local ped = PlayerPedId()
    RequestAnimDict("veh@break_in@0h@p_m_one@")
    while not HasAnimDictLoaded("veh@break_in@0h@p_m_one@") do
        Wait(10)
    end
    TaskPlayAnim(ped, "veh@break_in@0h@p_m_one@", "low_force_entry_ds", 3.0, 3.0, -1, 49, 0, false, false, false)

    TriggerEvent("meterlock:start", 2, function(success)
        ClearPedTasks(ped)

        if success then
            -- Coin spawn effect
            spawnCoinEffect(coords)

            -- Pickup animation & progress bar
            RequestAnimDict("pickup_object")
            while not HasAnimDictLoaded("pickup_object") do
                Wait(10)
            end

            QBCore.Functions.Progressbar("pickup_coins", "Collecting coins...", 4000, false, true, {
                disableMovement = true,
                disableCarMovement = true,
                disableMouse = false,
                disableCombat = true,
            }, {
                animDict = "pickup_object",
                anim = "pickup_low",
                flags = 49,
            }, {}, {}, function()
                TriggerServerEvent('qb-parkingmeters:server:giveLoot', model, coords)
            end)

        else
            -- Fail animation
            RequestAnimDict("anim@heists@prison_heiststation@cop_reactions")
            while not HasAnimDictLoaded("anim@heists@prison_heiststation@cop_reactions") do
                Wait(10)
            end
            TaskPlayAnim(ped, "anim@heists@prison_heiststation@cop_reactions", "cop_b_idle", 3.0, 3.0, 3000, 49, 0, false, false, false)
            Wait(3000)
            ClearPedTasks(ped)
        end
    end)
end)