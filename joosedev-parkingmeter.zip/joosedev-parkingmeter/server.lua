local QBCore = exports['qb-core']:GetCoreObject()

local meterCooldown = {}
local cooldown = 300 -- 5 minutes

local lootTable = {
    { item = "quarter", min = 5, max = 15, chance = 80 },  -- 60% chance
    { item = "cashroll", min = 1, max = 4, chance = 10 }, -- 30% chance
    { item = "rare_coin", min = 1, max = 1, chance = 10 }     -- 10% chance
}

QBCore.Functions.CreateCallback('qb-coinexchange:server:getCoinCount', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    local item = Player.Functions.GetItemByName('quarter')
    if item then
        cb(item.amount)
    else
        cb(0)
    end
end)

-- Process exchange
RegisterNetEvent('qb-coinexchange:server:exchangeCoins', function(count, worth)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    local item = Player.Functions.GetItemByName('quarter')
    if item and item.amount >= count then
        Player.Functions.RemoveItem('quarter', count)
        Player.Functions.AddMoney('cash', worth, "quarter-exchange")
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items['quarter'], "remove")
        TriggerClientEvent('QBCore:Notify', src, "You exchanged "..count.." quarters for $"..worth.." cash!", "success")
    else
        TriggerClientEvent('QBCore:Notify', src, "You don't have enough quarters!", "error")
    end
end)

-- Check cooldown and start minigame
RegisterNetEvent('qb-parkingmeters:server:checkCooldown', function(model, coords)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    if not Player then return end
    if not Player.Functions.GetItemByName('lockpick') then
        TriggerClientEvent('QBCore:Notify', src, "You need a lockpick!", "error")
        return
    end

    local key = tostring(model) .. "_" .. math.floor(coords.x) .. "_" .. math.floor(coords.y)

    if meterCooldown[key] and meterCooldown[key] > os.time() then
        local remaining = meterCooldown[key] - os.time()
        TriggerClientEvent('QBCore:Notify', src, "This meter was recently tampered with! Wait " .. remaining .. "s.", "error")
        return
    end

    -- Pass back to client to start the minigame
    TriggerClientEvent('qb-parkingmeters:client:startMinigame', src, model, coords)
end)

-- Give loot and set cooldown
RegisterNetEvent('qb-parkingmeters:server:giveLoot', function(model, coords)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    local roll = math.random(1, 100)
    local cumulativeChance = 0
    local givenLoot = false

    for _, loot in ipairs(lootTable) do
        cumulativeChance = cumulativeChance + loot.chance
        if roll <= cumulativeChance then
            local amount = math.random(loot.min, loot.max)
            Player.Functions.AddItem(loot.item, amount)
            TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[loot.item], "add")
            TriggerClientEvent('QBCore:Notify', src, "You found "..amount.." "..QBCore.Shared.Items[loot.item].label.."!", "success")
            givenLoot = true
            break -- ✅ Stop after giving the first matching item
        end
    end

    -- Set cooldown
    if givenLoot then
        local key = tostring(model) .. "_" .. math.floor(coords.x) .. "_" .. math.floor(coords.y)
        meterCooldown[key] = os.time() + cooldown
    end
end)

-- Break lockpick
RegisterNetEvent('qb-parkingmeters:server:breakLockpick', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    Player.Functions.RemoveItem('lockpick', 1)
    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items['lockpick'], "remove")
    TriggerClientEvent('QBCore:Notify', src, "Your lockpick broke!", "error")
end)